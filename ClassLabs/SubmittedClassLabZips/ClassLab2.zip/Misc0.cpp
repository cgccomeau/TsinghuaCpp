#include <iostream>
using namespace std;
int main()
{
	int a, b;
	a = 4, b = 7;
	cout<<"Hello!\n";
	cout<<"Welcome to C++\n";
	cout<<"Yabba dabba yeet!" << endl;
	cout<<a + b << endl;
	cout<<a;
	return 0;
}