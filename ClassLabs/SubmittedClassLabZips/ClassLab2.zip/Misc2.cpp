#include <iostream>
using namespace std;

int main()
{
    cout << "int('A') = " << int('A') << endl;
   	cout << "int('E') = " << int('E') << endl;
   	cout << "int('I') = " << int('I') << endl;
   	cout << "int('O') = " << int('O') << endl;
   	cout << "int('U') = " << int('U') << endl;
    cout << "int('a') = " << int('a') << endl;
   	cout << "int('e') = " << int('e') << endl;
   	cout << "int('i') = " << int('i') << endl;
   	cout << "int('o') = " << int('o') << endl;
   	cout << "int('u') = " << int('u') << endl;
	return 0;
}